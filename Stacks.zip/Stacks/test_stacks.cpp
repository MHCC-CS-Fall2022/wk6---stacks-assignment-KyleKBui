//file name: test_stacks.cpp
//Author: kyle bui
//date: 11/9/22

#include "stack1.h"
#include "stack2.h"
#include "node2.h" 
#include <iostream>
#include <stack>
using namespace std;
using namespace kyle_bui;
using namespace kyle_bui_2;

bool compareStacks(std::stack<int>&, std::stack<int>&);
void showBottomToTop(std::stack<int>&);

int main()
{
	int user;
	int user2;
	int user_input;
	int user_input2;
	std::stack<int> s1;
	std::stack<int> s2;
	std::stack<int> s3;
	std::stack<int> s4;

	cout << "Enter up to 30 numbers you want to enter into the stack" << endl;
	for (int i = 0; i < 30; i++)
	{
		cin >> user;
		if (user < 0)
			break;
		else
			s1.push(user);
	}
	
	showBottomToTop(s1);

	cout << "Enter up to 30 numbers you want to enter into the second stack" << endl;
	for (int i = 0; i < 30; i++)
	{
		cin >> user_input;
		if(user_input < 0)
			break;
		else 
			s2.push(user_input);
	}

	if (compareStacks(s1, s2) == true)
		cout << "Both stacks are the same" << endl;
	else
		cout << "The stacks are not the same" << endl;

	cout << "Enter up to 30 numbers you want enter into the stack" << endl;
	for(int i = 0; i < 30; i++)
	{
		cin >> user2;
		if(user2 < 0)
			break;
		else
			s3.push(user2);
	}

	showBottomToTop(s3);
	
	cout << "Enter up to 30 numbers you want enter into the stack" << endl;
	for(int i = 0; i < 30; i++)
	{
		cin >> user2;
		if(user2 < 0)
			break;
		else
			s4.push(user2);
	}
	
	if (compareStacks(s3, s4) == true)
		cout << "Both stacks are the same" << endl;
	else
		cout << "The stacks are not the same" << endl;

	return EXIT_SUCCESS;
}

void showBottomToTop(std::stack<int>& s1)
{
	if (s1.empty())//verifies that stack isn't empty
		return;

	std::stack<int> temp;

	while(!s1.empty())//this while loop reverses the stack into a temp stack so bottom 
	{		  //of stack is on top to pop off and cout
		temp.push(s1.top());
		s1.pop();
	}

	while (!temp.empty())//this loop puts the stack back in original order 
	{		     //from the temp stack
		int num = temp.top();
		cout << num << " "; 
		temp.pop();
		s1.push(num);
	}

	cout << endl;

}

bool compareStacks(std::stack<int>& s1, std::stack<int>& s2)
{
	if (s1.empty() || s2.empty())//verifies both stacks are not empty
		return false;
	if (s1.size() != s2.size())//verifies if both stacks are the same size
		return false;
	
	//tempo stacks 
	std::stack<int> temp1 = s1;//makes copy of stack one
	std::stack<int> temp2 = s2;//makes copy of stack two

	while (!temp1.empty())//verifies stack isn't empty
	{
		if(temp1.top() == temp2.top())//compares stack 
		{
			temp1.pop();//removes top value so next value is accessable
			temp2.pop();//removes top value so next value is accessable
		}
		else
			return false;//if tops are not equal functions ends program and retuns false
	}
	return true;	
}




